# django_quick_auth/apps.py
from django.apps import AppConfig

class DjangoQuickAuthConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_quick_auth'